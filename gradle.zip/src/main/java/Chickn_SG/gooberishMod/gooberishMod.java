package Chickn_SG.gooberishMod;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.registry.GameRegistry;

@Mod(modid = "gbm", name = "Gooberish Mod", version = "1.0")
public class gooberishMod {
	
	public static Item itemPenis;
	public static Block blockShmeatWhite;
	public static Block blockShmeatPink;
	@EventHandler
	public void preInit(FMLPreInitializationEvent event) {
		//Item/Block itit and reg
		//Config Handling
		itemPenis = new ItemPenis().setUnlocalizedName("ItemPenis").setTextureName("gbm:itempenis");
		blockShmeatWhite = new BlockShmeatWhite(Material.grass).setBlockName("BlockShmeatWhite").setBlockTextureName("gbm:blockshmeatwhite");
		blockShmeatPink = new BlockShmeatPink(Material.grass).setBlockName("BlockShmeatPink").setBlockTextureName("gbm:blockshmeatpink");
		
		GameRegistry.registerItem(itemPenis, itemPenis.getUnlocalizedName().substring(5));
		GameRegistry.registerBlock(blockShmeatWhite, blockShmeatWhite.getUnlocalizedName().substring(5));
		GameRegistry.registerBlock(blockShmeatPink, blockShmeatPink.getUnlocalizedName().substring(5));
	}
	
	@EventHandler
	public void init(FMLInitializationEvent event) {
		GameRegistry.addRecipe(new ItemStack(blockShmeatWhite), new Object[]{"PPP",
		                                                                     "PPP",
		                                                                     "PPP", 'P', Items.porkchop
		});
		GameRegistry.addRecipe(new ItemStack(blockShmeatPink), new Object[]{"BBB",
                                                                            "BBB",
                                                                            "BBB", 'B', Items.beef
		});
		GameRegistry.addRecipe(new ItemStack(itemPenis), new Object[]{" P ",
                                                                      " W ",
                                                                      "WWW", 'P', blockShmeatPink, 'W', blockShmeatWhite
		});
	}
	
	@EventHandler
	public void postInit(FMLPostInitializationEvent event) {
		//
	}
}
