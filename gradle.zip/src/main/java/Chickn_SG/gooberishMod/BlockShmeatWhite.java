package Chickn_SG.gooberishMod;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class BlockShmeatWhite extends Block {

	protected BlockShmeatWhite(Material material) {
		super(material);
		// TODO Auto-generated constructor stub
	}

}
